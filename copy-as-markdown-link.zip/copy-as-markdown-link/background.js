const MENU_ID = "copy-md-link";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "Copy as Markdown link",
    contexts: ["selection", "page"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID && tab) run(tab, info.selectionText || "");
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === "copy-markdown-link" && tab) run(tab, "");
});

function run(tab, selectionText) {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: copyMarkdownLink,
    args: [selectionText],
  });
}

// Runs inside the page.
function copyMarkdownLink(selectionText) {
  const raw = selectionText || window.getSelection().toString() || document.title;
  const text = raw.trim().replace(/\s+/g, " ").replace(/([\[\]])/g, "\\$1");
  const url = location.href.replace(/\(/g, "%28").replace(/\)/g, "%29");
  const md = `[${text}](${url})`;

  const fallbackCopy = () => {
    const ta = document.createElement("textarea");
    ta.value = md;
    ta.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  };

  const toast = () => {
    const el = document.createElement("div");
    el.textContent = "Copied: " + md;
    el.style.cssText =
      "position:fixed;bottom:20px;right:20px;z-index:2147483647;max-width:60ch;" +
      "padding:10px 14px;background:#222;color:#fff;font:13px sans-serif;" +
      "border-radius:6px;opacity:.95;word-break:break-all";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2000);
  };

  navigator.clipboard.writeText(md).catch(fallbackCopy).finally(toast);
}
